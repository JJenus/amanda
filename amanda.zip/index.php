<?php
header("location: ./app");