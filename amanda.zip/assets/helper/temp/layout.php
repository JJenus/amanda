
  <?php include  HELPERPATH.'temp/header.php' ?> 
      
	    <?php include  HELPERPATH.'temp/_navbar.php' ?> 
	    <?php include  $main ?>

	  <?php include  HELPERPATH.'temp/scripts.php' ?> 
  </body>
   
</html> 
