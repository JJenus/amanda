<?php
header("location: ./login");